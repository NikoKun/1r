package finestra;
public class Principal{
    public static void main(String[] args) {
        Finestra f1 = new Finestra();
        //f1.setVisible(true);

        //Finestra f2 = new Finestra();
        //f2.setLocation(10,10);
        //f2.setVisible(true);
        
        

    }
}